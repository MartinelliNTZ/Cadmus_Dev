# -*- coding: utf-8 -*-
import os
import re

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsLayoutExporter, QgsProject

from ..core.ui.ProgressDialog import ProgressDialog
from ..core.ui.dialogs.ListSelectionDialog import ListSelectionDialog
from ..i18n.TranslationManager import STR
from .BasePlugin import BasePluginMTL
from ..resources.widgets.grid.GridCheckbox import GridCheckbox
from ..resources.widgets.grid.GridDoubleSpin import GridDoubleSpin
from ..resources.widgets.grid.GridComplexSelector import GridComplexSelector
from ..resources.widgets.grid.GridExecutionButtons import GridExecutionButtons
from ..utils.DependenciesManager import DependenciesManager
from ..utils.PDFUtils import PDFUtils
from ..utils.Preferences import Preferences
from ..utils.QgisMessageUtil import QgisMessageUtil
from ..utils.ToolKeys import ToolKey


class ExportAllLayoutsPlugin(BasePluginMTL):
    """
    Plugin para exportar todos os layouts do projeto em PDF, PNG e/ou SVG.

    Estende BasePluginMTL para:
    - Interface padronizada com MainLayout + AppBar
    - Persistência automática de preferências via _save_prefs()
    - Carregamento automático via _load_prefs()
    - Widgets autoconfiguráveis (widgets)
    """

    TOOL_KEY = ToolKey.EXPORT_ALL_LAYOUTS

    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface = iface
        self._suppress_merge_dependency_check = False
        self._selected_layouts = set()

        self.init(
            self.TOOL_KEY,
            "ExportAllLayoutsDialog",
            load_system_prefs=False,
            build_ui=True,
        )

    def _build_ui(self, **kwargs):
        self.logger.debug("Construindo UI de exportação de layouts")

        super()._build_ui(
            title=STR.EXPORT_ALL_LAYOUTS_TITLE,
            icon_path="export_icon.ico",
            enable_scroll=False,
        )

        self.logger.info("Construindo componentes de interface")

        # ── Checkboxes de Exportação ──────────────────────────────
        self.checkbox_widget = GridCheckbox(
            config={
                "export_pdf": {
                    "label": F"{STR.EXPORT} PDF",
                    "description": "Exporta layouts em formato PDF",
                    "default": True,
                },
                "export_png": {
                    "label": F"{STR.EXPORT} PNG",
                    "description": "Exporta layouts em formato PNG",
                    "default": False,
                },
                "export_svg": {
                    "label": F"{STR.EXPORT} SVG",
                    "description": "Exporta layouts em formato SVG (vetorial)",
                    "default": False,
                },
                "georeference_pdf": {
                    "label": STR.GEOREFERENCE_PDF,
                    "description": STR.GEOREFERENCE_PDF_DESC,
                    "default": False,
                },
                "merge_pdf": {
                    "label": STR.MERGE_PDFS_FINAL,
                    "description": "Combina todos os PDFs em um único arquivo",
                    "default": False,
                    "onchange": self.on_merge_pdf_changed,
                },
                "merge_png": {
                    "label": STR.MERGE_PNGS_FINAL,
                    "description": "Combina todos os PNGs em um único PDF",
                    "default": False,
                    "onchange": self.on_merge_png_changed,
                },
                "replace_existing": {
                    "label": STR.REPLACE_EXISTING_FILES,
                    "description": "Substitui arquivos existentes sem criar cópias numeradas",
                    "default": False,
                },
            },
            items_per_row=2,
            title=STR.EXPORT_OPTIONS,
            separator_top=False,
            separator_bottom=True,
            parent=self,
        )
        self.layout.addWidget(self.checkbox_widget)

        self.logger.debug("Grid de checkboxes de exportação criado")

        # ── Max Width ─────────────────────────────────────────────
        self.max_width_input = GridDoubleSpin(
            config={
                "max_width": {
                    "label": STR.MAX_WIDTH_PNG,
                    "description": "Largura máxima em pixels para exportação PNG",
                    "value": 3500,
                    "min": 100,
                    "max": 10000,
                    "step": 100,
                    "decimals": 0,
                    "type": "int",
                },
            },
            separator_top=False,
            separator_bottom=True,
            parent=self,
        )
        self.layout.addWidget(self.max_width_input)
        self.logger.debug("Widget de Max Width criado")

        # ── DPI ───────────────────────────────────────────────────
        self.dpi_input = GridDoubleSpin(
            config={
                "dpi": {
                    "label": STR.DPI_OUTPUT,
                    "description": STR.DPI_OUTPUT_DESC,
                    "value": 0,
                    "min": 0,
                    "max": 1200,
                    "step": 10,
                    "decimals": 0,
                    "type": "int",
                },
            },
            separator_top=False,
            separator_bottom=True,
            parent=self,
        )
        self.layout.addWidget(self.dpi_input)
        self.logger.debug("Widget de DPI criado")

        # ── Output Folder ─────────────────────────────────────────
        default_path = os.path.join(QgsProject.instance().homePath(), "exports")
        self.folder_selector = GridComplexSelector(
            config={
                "output_folder": {
                    "label": STR.OUTPUT_FOLDER,
                    "description": "Pasta onde os arquivos exportados serão salvos",
                    "path": default_path,
                    "mode_type": "output",
                    "allow_file": False,
                    "allow_folder": True,
                    "subfolder": "exports",
                },
            },
            tool_key=self.TOOL_KEY,
            separator_top=False,
            separator_bottom=False,
            parent=self,
        )
        self.layout.addWidget(self.folder_selector)
        self.logger.debug("Path Selector de pasta de saída criado")

        # ── Execution Buttons ─────────────────────────────────────
        self.action_buttons = GridExecutionButtons(
            config={
                "layouts": {
                    "label": STR.SELECT_LAYOUTS,
                    "description": STR.SELECT_LAYOUTS_DESC,
                    "callback": self.open_layouts_selection,
                },
                "exportar": {
                    "label": STR.EXPORT,
                    "description": "Inicia a exportação dos layouts",
                    "callback": self.execute_tool,
                    "is_run_button": True,
                },
            },
            enable_close_button=True,
            enable_config_button=True,
            enable_info=True,
            tool_key=self.TOOL_KEY,
            parent=self,
        )
        self.layout.add_execution_buttons(self.action_buttons)
        self.logger.debug("Botões de ação criados")

        self.logger.info("Interface de exportação construída com sucesso")

    def open_layouts_selection(self):
        """Abre o diálogo de seleção de layouts."""
        self.logger.debug("Abrindo diálogo de seleção de layouts")

        project = QgsProject.instance()
        layouts = project.layoutManager().layouts()
        if not layouts:
            QgisMessageUtil.modal_error(self.iface, STR.NO_LAYOUTS_SELECTED)
            return

        items = {}
        for layout in layouts:
            name = layout.name()
            items[name] = {
                "label": name,
                "default": name in self._selected_layouts,
            }

        dlg = ListSelectionDialog(
            items=items,
            title=STR.SELECT_LAYOUTS_TITLE,
            hint=STR.SELECT_LAYOUTS_HINT,
            tool_key=self.TOOL_KEY,
            icon_path="export_icon.ico",
            parent=self,
        )
        if dlg.exec():
            self._selected_layouts = set(dlg.get_selected_items())
            self.logger.info(
                f"Layouts selecionados: {len(self._selected_layouts)}"
            )

    def _ensure_merge_dependency(
        self, *, checkbox_key: str, dependency_name: str, message: str
    ) -> bool:
        if DependenciesManager.check_dependency(dependency_name, self.TOOL_KEY):
            self.logger.info(
                f"Dependência {dependency_name} disponível para {checkbox_key}"
            )
            return True

        confirmed = QgisMessageUtil.confirm(
            self.iface,
            message,
            STR.REQUIRED_LIBRARY,
        )

        if not confirmed:
            self.logger.info(
                f"Usuário recusou instalação de {dependency_name}; desmarcando {checkbox_key}"
            )
            self.checkbox_widget.set_checked(checkbox_key, False)
            return False

        started = DependenciesManager.install_dependency_gui(
            dependency_name, self.iface, self.TOOL_KEY
        )

        if not started:
            self.logger.warning(
                f"Não foi possível iniciar instalação de {dependency_name}; desmarcando {checkbox_key}"
            )
            QgisMessageUtil.modal_error(
                self.iface,
                f"Não foi possível iniciar a instalação da biblioteca {dependency_name}.",
            )
            self.checkbox_widget.set_checked(checkbox_key, False)
            return False

        self.logger.info(
            f"Instalação de {dependency_name} iniciada a partir do checkbox {checkbox_key}"
        )
        return True

    def on_merge_pdf_changed(self, checked: bool):
        self.logger.debug(f"Estado do checkbox 'merge_pdf' alterado para: {checked}")
        if self._suppress_merge_dependency_check or not checked:
            return

        self._ensure_merge_dependency(
            checkbox_key="merge_pdf",
            dependency_name="colorama",
            message=STR.PYPDF2_REQUIRED_MESSAGE,
        )

    def on_merge_png_changed(self, checked: bool):
        self.logger.debug(f"Estado do checkbox 'merge_png' alterado para: {checked}")
        if self._suppress_merge_dependency_check or not checked:
            return

        self._ensure_merge_dependency(
            checkbox_key="merge_png",
            dependency_name="Pillow",
            message=STR.PILLOW_REQUIRED_MESSAGE,
        )

    def _load_prefs(self):
        self._suppress_merge_dependency_check = True
        try:
            self.checkbox_widget.set_preferences(
                self.preferences.get("checkbox_states")
            )
        finally:
            self._suppress_merge_dependency_check = False

        max_width = self.preferences.get("max_width", 3500)
        self.max_width_input.set_value("max_width", max_width)
        self.logger.debug(f"Max width carregado: {max_width}px")

        dpi = self.preferences.get("dpi", 0)
        self.dpi_input.set_value("dpi", dpi)
        self.logger.debug(f"DPI carregado: {dpi}")

        pasta_default = os.path.join(QgsProject.instance().homePath(), "exports")
        pasta_salva = self.preferences.get("output_folder", pasta_default)
        self.folder_selector.set_paths([pasta_salva])
        self.logger.debug(f"Pasta de saída carregada: {pasta_salva}")

        saved_layouts = self.preferences.get("selected_layouts", [])
        self._selected_layouts = set(saved_layouts or [])
        self.logger.debug(
            f"Layouts selecionados carregados: {len(self._selected_layouts)}"
        )

    def _save_prefs(self):
        self.logger.debug("Salvando preferências de exportação")

        self.preferences["checkbox_states"] = self.checkbox_widget.get_preferences()

        all_values = self.max_width_input.get_all_values()
        self.preferences["max_width"] = int(all_values.get("max_width", 3500))

        all_dpi_values = self.dpi_input.get_all_values()
        self.preferences["dpi"] = int(all_dpi_values.get("dpi", 0))

        paths = self.folder_selector.get_paths()
        pasta = (
            paths[0]
            if paths
            else os.path.join(QgsProject.instance().homePath(), "exports")
        )
        self.preferences["output_folder"] = pasta

        self.preferences["selected_layouts"] = list(self._selected_layouts)

        Preferences.save_tool_prefs(self.TOOL_KEY, self.preferences)
        self.logger.info("Preferências de exportação salvas com sucesso")

    def execute_tool(self):
        self.logger.info("Iniciando exportação de layouts")

        all_states = self.checkbox_widget.get_all_states()
        export_pdf = all_states.get("export_pdf", True)
        export_png = all_states.get("export_png", False)
        export_svg = all_states.get("export_svg", False)
        georeference_pdf = all_states.get("georeference_pdf", False)
        merge_pdf = all_states.get("merge_pdf", False)
        merge_png = all_states.get("merge_png", False)
        replace_existing = all_states.get("replace_existing", False)

        all_values = self.max_width_input.get_all_values()
        max_width = int(all_values.get("max_width", 3500))

        all_dpi_values = self.dpi_input.get_all_values()
        dpi = int(all_dpi_values.get("dpi", 0))

        paths = self.folder_selector.get_paths()
        output_folder = (
            paths[0]
            if paths
            else os.path.join(QgsProject.instance().homePath(), "exports")
        )

        if not export_pdf and not export_png and not export_svg:
            QgisMessageUtil.modal_error(
                self.iface, STR.SELECT_AT_LEAST_ONE_EXPORT_FORMAT
            )
            return

        project = QgsProject.instance()
        layouts = project.layoutManager().layouts()

        # Filtra layouts selecionados (se houver seleção)
        if self._selected_layouts:
            layouts = [
                layout
                for layout in layouts
                if layout.name() in self._selected_layouts
            ]
            self.logger.info(
                f"Filtrando para {len(layouts)} layout(s) selecionado(s)"
            )

        if not layouts:
            QgisMessageUtil.modal_error(self.iface, STR.NO_LAYOUTS_SELECTED)
            return

        os.makedirs(output_folder, exist_ok=True)
        self.logger.info(f"Pasta de saída: {output_folder}")

        if merge_pdf and not DependenciesManager.check_dependency(
            "PyPDF2", self.TOOL_KEY
        ):
            self.logger.warning(
                "Merge de PDF solicitado sem PyPDF2 disponível; merge será ignorado"
            )
            merge_pdf = False
            self.checkbox_widget.set_checked("merge_pdf", False)

        if merge_png and not DependenciesManager.check_dependency(
            "Pillow", self.TOOL_KEY
        ):
            self.logger.warning(
                "Merge de PNG solicitado sem Pillow disponível; merge será ignorado"
            )
            merge_png = False
            self.checkbox_widget.set_checked("merge_png", False)

        pdf_list = []
        png_list = []
        total = len(layouts)
        self.logger.info(f"Iniciando exportação de {total} layout(s)")

        progress = ProgressDialog(STR.EXPORTING_LAYOUTS, STR.CANCEL, 0, total, self)
        progress.show()

        erros = []
        sucesso = 0

        for i, layout in enumerate(layouts):
            progress.set_value(i)
            QCoreApplication.processEvents()

            if progress.is_canceled():
                self.logger.warning(
                    f"Exportação cancelada pelo usuário em layout {i + 1}/{total}"
                )
                break

            nome = re.sub(r'[<>:"/\\|?*]', "", layout.name().strip())
            pdf_path = os.path.join(output_folder, f"{nome}.pdf")
            png_path = os.path.join(output_folder, f"{nome}.png")
            svg_path = os.path.join(output_folder, f"{nome}.svg")

            if not replace_existing:
                base = nome
                count = 1
                while (
                    os.path.exists(pdf_path)
                    or os.path.exists(png_path)
                    or os.path.exists(svg_path)
                ):
                    nome_novo = f"{base}_{count}"
                    pdf_path = os.path.join(output_folder, f"{nome_novo}.pdf")
                    png_path = os.path.join(output_folder, f"{nome_novo}.png")
                    svg_path = os.path.join(output_folder, f"{nome_novo}.svg")
                    count += 1

            try:
                exporter = QgsLayoutExporter(layout)
                ok_pdf = ok_png = ok_svg = True

                if export_pdf:
                    pdf_settings = QgsLayoutExporter.PdfExportSettings()
                    pdf_settings.georeference = georeference_pdf
                    if dpi > 0:
                        pdf_settings.dpi = dpi
                    result = exporter.exportToPdf(pdf_path, pdf_settings)
                    ok_pdf = result == QgsLayoutExporter.Success
                    if ok_pdf:
                        pdf_list.append(pdf_path)
                        self.logger.debug(
                            f"PDF exportado: {pdf_path} "
                            f"(georeference={georeference_pdf}, dpi={pdf_settings.dpi})"
                        )
                    else:
                        erros.append(f"{STR.FAILED_EXPORT_PDF} {nome}")

                if export_png:
                    image_settings = QgsLayoutExporter.ImageExportSettings()
                    if dpi > 0:
                        image_settings.dpi = dpi
                    result = exporter.exportToImage(png_path, image_settings)
                    ok_png = result == QgsLayoutExporter.Success
                    if ok_png:
                        png_list.append(png_path)
                        self.logger.debug(
                            f"PNG exportado: {png_path} (dpi={image_settings.dpi})"
                        )
                    else:
                        erros.append(f"{STR.FAILED_EXPORT_PNG} {nome}")

                if export_svg:
                    svg_settings = QgsLayoutExporter.SvgExportSettings()
                    if dpi > 0:
                        svg_settings.dpi = dpi
                    result = exporter.exportToSvg(svg_path, svg_settings)
                    ok_svg = result == QgsLayoutExporter.Success
                    if ok_svg:
                        self.logger.debug(
                            f"SVG exportado: {svg_path} (dpi={svg_settings.dpi})"
                        )
                    else:
                        erros.append(f"{STR.ERROR_EXPORTING} SVG: {nome}")

                if ok_pdf or ok_png or ok_svg:
                    sucesso += 1

            except Exception as e:
                erro_msg = f"{STR.ERROR_EXPORTING} {nome}: {str(e)}"
                self.logger.error(erro_msg)
                erros.append(erro_msg)

        self.logger.info(
            f"Loop de exportação concluído: {sucesso}/{total} layouts processados com sucesso"
        )

        progress.set_value(total)
        progress.close()

        merge_pdf_success = False
        if merge_pdf and pdf_list:
            self.logger.debug(f"Unindo {len(pdf_list)} PDFs")
            ok, msg_text = PDFUtils.merge_pdfs(
                pdf_list, os.path.join(output_folder, "_PDF_UNICO_FINAL.pdf")
            )
            if ok:
                self.logger.info(f"PDFs unidos com sucesso: {msg_text}")
                merge_pdf_success = True
            else:
                self.logger.warning(f"Falha ao unir PDFs: {msg_text}")
                erros.append(f"{STR.FAILED_MERGE_PDFS} {msg_text}")

        merge_png_success = False
        if merge_png and png_list:
            self.logger.info(
                f"Iniciando merge de {len(png_list)} PNGs em PDF (max_width={max_width}px)"
            )
            ok, msg_text = PDFUtils.merge_pngs_to_pdf(
                png_list,
                os.path.join(output_folder, "_PNG_MERGED_FINAL.pdf"),
                max_width,
            )
            if ok:
                self.logger.info(f"PNGs unidos com sucesso: {msg_text}")
                merge_png_success = True
            else:
                self.logger.warning(f"Falha ao unir PNGs: {msg_text}")
                erros.append(f"{STR.FAILED_MERGE_PNGS} {msg_text}")

        texto = ""
        if erros:
            texto += f"<b>{STR.ERRORS_FOUND}</b><br>" + "<br>".join(erros) + "<br><br>"

        sucesso_text = f"<b>{sucesso}</b> {STR.LAYOUTS_EXPORTED_SUCCESS}"
        if merge_pdf_success:
            sucesso_text += f"<br><b>{STR.PDFS_MERGED}</b> em _PDF_UNICO_FINAL.pdf"
        if merge_png_success:
            sucesso_text += f"<br><b>{STR.PNGS_MERGED}</b> em _PNG_MERGED_FINAL.pdf"

        texto += sucesso_text

        try:
            QgisMessageUtil.modal_result_with_folder(
                self.iface,
                STR.EXPORT_LAYOUTS_COMPLETED,
                texto,
                output_folder,
                parent=self,
            )
        except Exception as modal_error:
            self.logger.error(
                f"Erro ao exibir diálogo de resultado: {str(modal_error)}"
            )
            raise


def run(iface):
    """Função de entrada do plugin."""
    dlg = ExportAllLayoutsPlugin(iface)
    dlg.setModal(False)
    dlg.show()
    return dlg
