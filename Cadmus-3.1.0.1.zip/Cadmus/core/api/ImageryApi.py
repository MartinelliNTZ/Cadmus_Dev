# -*- coding: utf-8 -*-
"""
ImageryApi — Cliente de catálogo STAC (imagens de satélite) e download.
========================================================================
Roda em thread de trabalho (tasks). Usa apenas stdlib, requests,
pystac_client, osgeo/gdal, numpy e pyproj — **sem objetos QGIS**
(QgsProject, QgsLayer, canvas). Apenas paths e geometrias serializadas.

Primeira fonte: Sentinel-2 L2A via Earth Search (Element 84).
"""

import json
import os
import threading
from pathlib import Path
from typing import Callable, Optional, Union

import requests

from ...utils.BaseUtil import BaseUtil
from ...utils.ExplorerUtils import ExplorerUtils
from ...utils.raster.RasterLayerProcessing import RasterLayerProcessing
from ...utils.raster.RasterVectorBridge import RasterVectorBridge


# Lock global para operações GDAL/OGR (worker-safe) — regra SKILL_UTILS 2.3.2
_GDAL_LOCK = threading.Lock()


# ── Downloads HTTP compartilhados ──────────────────────────────────────
# Session única com keep-alive: as bandas da mesma cena vêm do mesmo host S3,
# então reutilizar conexões elimina handshake TLS/TCP a cada banda baixada.
_HTTP_SESSION = None
_HTTP_SESSION_LOCK = threading.Lock()

# Downloads de banda simultâneos dentro de uma cena. A rede é o gargalo
# dominante; o GDAL continua serializado via _GDAL_LOCK (regra SKILL_UTILS
# 2.3.2). 4 fluxos é um bom equilíbrio entre ganho e saturação de banda.
MAX_BAND_DOWNLOADS = 4

# 1 MiB por chunk reduz drasticamente o overhead de syscall no iter_content.
DOWNLOAD_CHUNK_SIZE = 1024 * 1024


def _get_http_session() -> "requests.Session":
    """Retorna a Session HTTP global (lazy e thread-safe, keep-alive + retry)."""
    global _HTTP_SESSION
    if _HTTP_SESSION is None:
        with _HTTP_SESSION_LOCK:
            if _HTTP_SESSION is None:
                from requests.adapters import HTTPAdapter, Retry

                session = requests.Session()
                retry = Retry(
                    total=3,
                    backoff_factor=0.5,
                    status_forcelist=(429, 500, 502, 503, 504),
                )
                adapter = HTTPAdapter(
                    pool_connections=8, pool_maxsize=16, max_retries=retry
                )
                session.mount("https://", adapter)
                session.mount("http://", adapter)
                _HTTP_SESSION = session
    return _HTTP_SESSION


class ImageryApi(BaseUtil):
    """Cliente de catálogo STAC e download de imagens de satélite.

    Fonte primária: Sentinel-2 L2A (collection ``sentinel-2-l2a``).
    O atributo ``SOURCES`` permite adicionar novas fontes no futuro.

    Parâmetros
    ----------
    tool_key : str, optional
        ToolKey para logging rastreável (via BaseUtil).
    """

    STAC_URL = "https://earth-search.aws.element84.com/v1"
    CHAVES_THUMB = ["thumbnail", "overview"]
    DEFAULT_SOURCE = "sentinel2"

    SOURCES = {
        "sentinel2": {
            "label": "Sentinel-2 L2A",
            "collection": "sentinel-2-l2a",
            "assets": {
                "B01": ("Coastal Aerosol", "60m"),
                "B02": ("Blue", "10m"),
                "B03": ("Green", "10m"),
                "B04": ("Red", "10m"),
                "B05": ("Red Edge", "20m"),
                "B06": ("Red Edge", "20m"),
                "B07": ("Red Edge", "20m"),
                "B08": ("Near Infrared", "10m"),
                "B8A": ("Red Edge", "20m"),
                "B09": ("Water Vapour", "60m"),
                "B11": ("SWIR 1", "20m"),
                "B12": ("SWIR 2", "20m"),
                "SCL": ("Scene Classification", "20m"),
            },
            "asset_map": {
                "B01": ["coastal", "B01"],
                "B02": ["blue", "B02"],
                "B03": ["green", "B03"],
                "B04": ["red", "B04"],
                "B05": ["rededge1", "B05"],
                "B06": ["rededge2", "B06"],
                "B07": ["rededge3", "B07"],
                "B08": ["nir", "B08"],
                "B8A": ["nir08", "B8A"],
                "B09": ["nir09", "B09"],
                "B11": ["swir16", "B11"],
                "B12": ["swir22", "B12"],
                "SCL": ["scl", "SCL"],
            },
            "compositions": {
                "RGB": {"nome": "RGB Natural", "bandas": ["B04", "B03", "B02"]},
                "FALSA_COR": {"nome": "Falsa Cor (NIR)", "bandas": ["B08", "B04", "B03"]},
                "SWIR": {"nome": "SWIR (Vegetação)", "bandas": ["B12", "B8A", "B04"]},
                "AGRICULTURA": {"nome": "Agricultura", "bandas": ["B11", "B08", "B02"]},
                "URBANO": {"nome": "Índice Urbano", "bandas": ["B12", "B11", "B04"]},
                "NDVI": {"nome": "NDVI (Vegetação)", "bandas": ["B08", "B04"]},
                "TODAS": {"nome": "Todas as bandas", "bandas": None},
            },
        },
    }

    def __init__(self, tool_key: Optional[str] = None):
        """Inicializa o cliente STAC (lazy) com tool_key de rastreamento."""
        super().__init__(tool_key or BaseUtil.TOOL_KEY_UNTRACEABLE)
        self._client = None

    # ── Catálogo / configuração da fonte ─────────────────────────────

    def get_source_config(self, source: Optional[str] = None) -> dict:
        """Retorna a config da fonte (assets, asset_map, compositions, collection)."""
        src = source or self.DEFAULT_SOURCE
        cfg = self.SOURCES.get(src)
        if cfg is None:
            raise ValueError(f"Fonte STAC desconhecida: {src}")
        return cfg

    def source_labels(self) -> dict:
        """Retorna {chave: label} de todas as fontes (para GridComboBox)."""
        return {key: cfg.get("label", key) for key, cfg in self.SOURCES.items()}

    # ── Cliente STAC ─────────────────────────────────────────────────

    def _open_client(self):
        """Abre (lazy) o cliente STAC."""
        if self._client is None:
            from pystac_client import Client  # import tardio (validação RF1)

            self._client = Client.open(self.STAC_URL)
        return self._client

    # ── Busca de cenas ───────────────────────────────────────────────

    def search_scenes(
        self,
        bbox_wgs84,
        date_from: str,
        date_to: str,
        max_cloud: float = 100.0,
        source: Optional[str] = None,
        max_items: int = 200,
    ) -> list:
        """Busca cenas no STAC para a bbox/intervalo/% de nuvens.

        Parâmetros
        ----------
        bbox_wgs84 : list[float]
            Extent em EPSG:4326 [xmin, ymin, xmax, ymax].
        date_from : str
            Data inicial (YYYY-MM-DD).
        date_to : str
            Data final (YYYY-MM-DD).
        max_cloud : float
            Nuvens máximas (eo:cloud_cover <= max_cloud).
        source : str, optional
            Chave da fonte (default "sentinel2").
        max_items : int
            Limite de itens retornados (default 200).

        Returns
        -------
        list[dict]
            Cenas normalizadas (id, date, tile, plataforma, nuvens, assets,
            geometry, proj_epsg, datetime).
        """
        cfg = self.get_source_config(source)
        catalog = self._open_client()
        self.logger.info(
            "Busca STAC iniciada",
            code="IMAGERY_SEARCH_START",
            bbox=bbox_wgs84,
            date_from=date_from,
            date_to=date_to,
            max_cloud=float(max_cloud),
        )

        search = catalog.search(
            collections=[cfg["collection"]],
            bbox=bbox_wgs84,
            datetime=f"{date_from}/{date_to}",
            query={"eo:cloud_cover": {"lte": float(max_cloud)}},
            max_items=max_items,
        )

        items = list(search.items())
        items.sort(key=lambda it: it.properties.get("datetime", ""))
        scenes = [self._normalize_scene(it) for it in items]

        self.logger.info(
            f"Busca STAC: {len(scenes)} cenas encontradas",
            code="IMAGERY_SEARCH_RESULT",
            total=len(scenes),
        )
        return scenes

    @staticmethod
    def _normalize_scene(item) -> dict:
        """Converte um Item do pystac em dict serializável (sem objetos de biblioteca)."""
        props = item.properties
        date = str(props.get("datetime", ""))[:10]
        mdate = str(props.get("datetime", "")) or ""
        return {
            "id": item.id,
            "date": date,
            "datetime": mdate,
            "tile": props.get("s2:mgrs_tile", props.get("mgrs:utm_zone", "")),
            "plataforma": str(props.get("platform", "")).upper(),
            "nuvens": float(props.get("eo:cloud_cover") or 0),
            "assets": {
                key: asset.href for key, asset in item.assets.items()
            } if item.assets else {},
            "geometry": item.geometry,
            "proj_epsg": props.get("proj:epsg"),
        }
# ── Thumbnail ────────────────────────────────────────────────────

    def get_thumbnail(self, scene: dict) -> Optional[bytes]:
        """Baixa a thumbnail (JPEG) da cena. Retorna None em falha."""
        assets = scene.get("assets", {}) or {}
        for key in self.CHAVES_THUMB:
            url = assets.get(key)
            if not url:
                continue
            try:
                resp = _get_http_session().get(url, timeout=30)
                resp.raise_for_status()
                return resp.content
            except Exception as e:  # noqa: BLE001 - thumbnail é opcional
                self.logger.warning(
                    f"get_thumbnail: falha em '{key}': {e}",
                    code="IMAGERY_THUMB_FAIL",
                    scene=scene.get("id"),
                )
        return None

    # ── Download de asset ────────────────────────────────────────────

    def download_asset(
        self,
        scene: dict,
        asset_key: str,
        dest_path: Union[str, Path],
        progress_cb: Optional[Callable[[float], None]] = None,
    ) -> str:
        """Baixa um asset (banda) da cena para `dest_path` com progresso."""
        url = (scene.get("assets") or {}).get(asset_key)
        if not url:
            raise RuntimeError(
                f"Asset '{asset_key}' nao encontrado na cena {scene.get('id')}"
            )

        dest_path = str(dest_path)
        parent = os.path.dirname(dest_path)
        if parent:
            os.makedirs(parent, exist_ok=True)

        self.logger.info(
            f"download_asset: {asset_key} ({scene.get('id')})",
            code="IMAGERY_DOWNLOAD_ASSET",
            url=url,
        )

        resp = _get_http_session().get(url, stream=True, timeout=(15, 300))
        resp.raise_for_status()
        total = int(resp.headers.get("content-length") or 0)
        written = 0
        with open(dest_path, "wb") as fh:
            for chunk in resp.iter_content(chunk_size=DOWNLOAD_CHUNK_SIZE):
                if not chunk:
                    continue
                fh.write(chunk)
                written += len(chunk)
                if progress_cb is not None and total:
                    progress_cb(min(100.0, written * 100.0 / total))
        if progress_cb is not None and not total:
            progress_cb(100.0)
        return dest_path

    # ── Resolvedores ─────────────────────────────────────────────────

    @staticmethod
    def resolve_asset_key(scene: dict, cfg: dict, banda: str) -> str:
        """Resolve a chave real do asset no catálogo a partir da banda lógica."""
        assets = scene.get("assets") or {}
        if banda in assets:
            return banda
        aliases = cfg.get("asset_map", {}).get(banda, [banda])
        for alias in aliases:
            if alias in assets:
                return alias
        return banda

    def resolve_bands(self, bands_cfg, source: Optional[str] = None) -> list:
        """Expande composições/checkboxes em uma lista única e ordenada de bandas.

        Aceita dict ``{banda_or_composicao: bool}`` ou list de bandas.
        Composições com ``bandas=None`` expandem para todas as bandas da fonte.
        """
        cfg = self.get_source_config(source)
        comps = cfg.get("compositions", {})
        all_bands = list(cfg.get("assets", {}).keys())
        result = []

        if isinstance(bands_cfg, dict):
            for key, enabled in bands_cfg.items():
                if not enabled:
                    continue
                if key in comps:
                    bandas = comps[key].get("bandas")
                    result.extend(bandas if bandas else all_bands)
                elif key in all_bands or key in cfg.get("asset_map", {}):
                    result.append(key)
        elif isinstance(bands_cfg, (list, tuple)):
            for key in bands_cfg:
                if key in comps:
                    bandas = comps[key].get("bandas")
                    result.extend(bandas if bandas else all_bands)
                else:
                    result.append(key)

        seen = set()
        unique = []
        for b in result:
            if b not in seen:
                seen.add(b)
                unique.append(b)
        return unique

    @staticmethod
    def _composicao_banda_path(pasta_item, prefixo: str, banda: str, convert_uint16: bool):
        """Resolve o path do produto final de uma banda para composição.

        Replica a regra de naming do `process_item`: ``{prefixo}_{banda}.tif``
        ou ``{prefixo}_{banda}_refl.tif`` quando convertido (÷10000). SCL nunca
        é convertido.
        """
        eh_scl = str(banda).upper() == "SCL"
        nome = f"{prefixo}_{banda}.tif"
        if convert_uint16 and not eh_scl:
            nome = f"{prefixo}_{banda}_refl.tif"
        return Path(pasta_item) / nome

    @staticmethod
    def resolve_epsg(epsg_cfg, source_epsg: Optional[int]) -> Optional[int]:
        """Resolve o EPSG de saída.

        - "utm"/"native"/vazio → None (CRS nativo da cena).
        - int ou "EPSG:xxxx" → int do EPSG escolhido.
        """
        if isinstance(epsg_cfg, int):
            return epsg_cfg if epsg_cfg > 0 else None
        v = str(epsg_cfg or "").strip().lower()
        if v in ("utm", "native", ""):
            return None
        try:
            if ":" in v:
                return int(v.split(":")[-1])
            return int(v)
        except ValueError:
            return source_epsg
# ── Processamento nativo GDAL (worker-safe) ──────────────────────

    @staticmethod
    def _get_raster_epsg(raster_path: str) -> Optional[int]:
        """Retorna o EPSG do raster via GDAL (sem objetos QGIS)."""
        from osgeo import gdal
        from osgeo import osr

        src_ds = gdal.Open(str(raster_path), gdal.GA_ReadOnly)
        if src_ds is None:
            return None
        proj = src_ds.GetProjection()
        src_ds = None
        if not proj:
            return None
        srs = osr.SpatialReference()
        srs.ImportFromWkt(proj)
        code = srs.GetAuthorityCode(None)
        return int(code) if code else None

    def _reproject_raster(self, src_path, target_epsg: int, output_path) -> str:
        """Reprojeta raster via ``gdal.Warp`` (thread-safe, sem QGIS)."""
        from osgeo import gdal

        src_ds = gdal.Open(str(src_path), gdal.GA_ReadOnly)
        if src_ds is None:
            raise RuntimeError(f"Nao foi possivel abrir raster: {src_path}")

        parent = os.path.dirname(str(output_path))
        if parent:
            os.makedirs(parent, exist_ok=True)

        options = gdal.WarpOptions(
            dstSRS=f"EPSG:{int(target_epsg)}",
            format="GTiff",
            resampleAlg="bilinear",
        )
        try:
            result = gdal.Warp(str(output_path), src_ds, options=options)
        finally:
            src_ds = None
        if result is None:
            raise RuntimeError(
                f"Falha ao reprojetar raster para EPSG:{target_epsg}"
            )
        self.logger.info(
            f"Raster reprojetado p/ EPSG:{target_epsg} -> {output_path}",
            code="IMAGERY_REPROJECT_DONE",
        )
        return str(output_path)

    def _resample_raster(self, src_path, output_path, target_res: float) -> str:
        """Reamostra o raster a uma resolução alvo via ``gdal.Warp``.

        Unifica o grid de bandas com resolução mista (ex.: 20m -> 10m) antes
        de compor uma composição colorida. Worker-safe, usa só paths (sem QGIS).
        """
        from osgeo import gdal

        src_ds = gdal.Open(str(src_path), gdal.GA_ReadOnly)
        if src_ds is None:
            raise RuntimeError(f"Nao foi possivel abrir raster: {src_path}")

        parent = os.path.dirname(str(output_path))
        if parent:
            os.makedirs(parent, exist_ok=True)

        options = gdal.WarpOptions(
            format="GTiff",
            xRes=target_res,
            yRes=target_res,
            resampleAlg="bilinear",
        )
        try:
            result = gdal.Warp(str(output_path), src_ds, options=options)
        finally:
            src_ds = None
        if result is None:
            raise RuntimeError(f"Falha ao reamostrar raster a {target_res}")
        self.logger.info(
            f"Banda reamostrada a {target_res} -> {output_path}",
            code="IMAGERY_RESAMPLE_DONE",
            target_res=target_res,
        )
        return str(output_path)

    @staticmethod
    def _band_resolucion_m(res_str) -> Optional[float]:
        """Converte o sufixo de resolução (``"10m"``) a float (``10.0``)."""
        if not res_str:
            return None
        try:
            return float(str(res_str).strip().lower().replace("m", ""))
        except (TypeError, ValueError):
            return None

    def _clip_by_extent(
        self,
        src_path,
        extent_wgs84,
        scene_epsg,
        output_path,
    ) -> str:
        """Recorta pelo boundary da extensão (bbox WGS84) no CRS da cena.

        Usa ``gdal.Translate`` com ``projWin`` calculado via pyproj
        (thread-safe, sem objetos QGIS).
        """
        from osgeo import gdal

        if not scene_epsg:
            self.logger.warning(
                "Recorte por extenso sem EPSG da cena; usando raster sem recorte",
                code="IMAGERY_CLIP_NO_EPSG",
            )
            return src_path

        from pyproj import Transformer

        transformer = Transformer.from_crs(
            "EPSG:4326", f"EPSG:{int(scene_epsg)}", always_xy=True
        )
        xmin, ymin, xmax, ymax = extent_wgs84
        xs = []
        ys = []
        for lx, ly in ((xmin, ymin), (xmin, ymax), (xmax, ymin), (xmax, ymax)):
            px, py = transformer.transform(lx, ly)
            xs.append(px)
            ys.append(py)
        # gdal projWin: [ulx, uly, lrx, lry]
        proj_win = [min(xs), max(ys), max(xs), min(ys)]

        src_ds = gdal.Open(str(src_path), gdal.GA_ReadOnly)
        if src_ds is None:
            raise RuntimeError(f"Nao foi possivel abrir raster: {src_path}")

        parent = os.path.dirname(str(output_path))
        if parent:
            os.makedirs(parent, exist_ok=True)

        # Remove saída existente antes do gdal.Translate (evita WinError 183 /
        # "cannot create a file already exists" em re-execuções no Windows).
        if os.path.exists(str(output_path)):
            ExplorerUtils.delete_file(str(output_path), tool_key=self.tool_key)

        try:
            result = gdal.Translate(str(output_path), src_ds, projWin=proj_win)
        finally:
            src_ds = None
        if result is None:
            raise RuntimeError("Falha ao recortar raster pelo boundary")
        self.logger.info(
            f"Raster recortado pelo boundary -> {output_path}",
            code="IMAGERY_CLIP_EXTENT_DONE",
        )
        return str(output_path)

    def create_polygon_mask(self, wkt: str, dest_path: str) -> str:
        """Cria máscara vetorial temporária (GPKG) a partir de WKT de polígono.

        O polígono é gravado em EPSG:4326 (padrão do widget GridBBoxSelector
        quando `tipo="drawn"`). Worker-safe: usa apenas GDAL/OGR, sob o
        `_GDAL_LOCK`, sem objetos QGIS.

        Parâmetros
        ----------
        wkt : str
            WKT do polígono em EPSG:4326.
        dest_path : str
            Caminho do GPKG de máscara a criar.

        Retorna
        -------
        str
            Caminho do GPKG criado.
        """
        from osgeo import ogr, osr

        dest_path = str(dest_path)
        parent = os.path.dirname(dest_path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        if os.path.exists(dest_path):
            ExplorerUtils.delete_file(dest_path, tool_key=self.tool_key)

        with _GDAL_LOCK:
            geometry = ogr.CreateGeometryFromWkt(wkt)
            if geometry is None:
                raise ValueError("WKT de polígono desenhado inválido")

            driver = ogr.GetDriverByName("GPKG")
            data_source = driver.CreateDataSource(dest_path)
            if data_source is None:
                raise RuntimeError(f"Falha ao criar GPKG de máscara: {dest_path}")
            try:
                srs = osr.SpatialReference()
                srs.SetFromUserInput("EPSG:4326")
                layer = data_source.CreateLayer("mask", srs, ogr.wkbPolygon)
                feature = ogr.Feature(layer.GetLayerDefn())
                feature.SetGeometry(geometry)
                layer.CreateFeature(feature)
                feature = None
            finally:
                data_source = None

        self.logger.info(
            "Máscara de polígono criada para recorte",
            code="IMAGERY_MASK_CREATED",
            path=dest_path,
        )
        return dest_path

    # ── Processamento de item (cena) ─────────────────────────────────

    @staticmethod
    def compute_prefixo(item: dict) -> str:
        """Calcula o prefixo (subpasta) de uma cena: data_tile_plataforma.

        Usado também por DownloadDateTask para detectar colisão de pastas
        entre cenas da mesma data antes de paralelizar o download.
        """
        return (
            ExplorerUtils.sanitize_path_component(
                f"{item.get('date', '')}_{item.get('tile', '')}_{item.get('plataforma', '')}"
            )
            or item.get("id", "item")
        )

    def process_item(
        self,
        item: dict,
        bandas: list,
        clip_mode: Optional[str],
        clip_geom: Optional[dict],
        epsg_out: Optional[int],
        output_folder: str,
        convert_uint16: bool = True,
        delete_originals: bool = False,
        compositions: Optional[list] = None,
        progress_cb: Optional[Callable[[float], None]] = None,
        unique_by_item: bool = False,
    ) -> dict:
        """Baixa e processa as bandas de uma cena.

        Parâmetros
        ----------
        item : dict
            Cena normalizada (de ``search_scenes``).
        bandas : list[str]
            Bandas lógicas (ex: B04, B03, B02).
        clip_mode : str | None
            ``"polygon"`` (recorte por camada de polígono), ``"extent"``
            (recorte pelo boundary da extensão) ou ``None``.
        clip_geom : dict | None
            ``{"polygon_path": str}`` para polygon; ``{"extent_wgs84": list}``
            para extent.
        epsg_out : int | None
            EPSG de saída (None = nativo da cena).
        output_folder : str
            Pasta raiz de saída (cada cena em ``{folder}/data_tile_plataforma``).
        convert_uint16 : bool
            Se True, divide por 10000 e salva float32 ``_refl.tif``.
        delete_originals : bool
            Se True, lista os originais uint16 para remoção (feita no main thread).
        compositions : list[str], optional
            Chaves lógicas de composições pré-populadas a gerar após baixar
            as bandas (ex.: ``["RGB"]``). Resolução mista (20m+10m) é unificada
            re-amostrando as bandas grossas para a banda mais fina da composição.
        progress_cb : callable, optional
            Callback de progresso 0-100.
        unique_by_item : bool, optional
            Se True, inclui o id único da cena no prefixo/pasta (necessário
            quando várias cenas da mesma data compartilham data+tile grid+
            plataforma e rodam em paralelo — evita corromper os `_tmp_*.tif`).

        Returns
        -------
        dict
            Resultado com ``item_id``, ``prefix``, ``folder``, ``files``,
            ``originals_to_delete`` e ``metadata`` (path do JSON).
        """
        cfg = self.get_source_config(None)
        prefixo = self.compute_prefixo(item)
        if unique_by_item:
            # Mosaico da mesma data: cenas podem compartilhar data+tile grid+
            # plataforma (ex: 22LDJ vs 22LCJ). Com paralelismo, pastas iguais
            # corromperiam os _tmp_*.tif; adiciona o id único da cena à pasta.
            slug_id = (
                ExplorerUtils.sanitize_path_component(item.get("id", ""))
                or "item"
            )
            prefixo = f"{prefixo}_{slug_id}"
        pasta_item = Path(output_folder) / prefixo
        pasta_item.mkdir(parents=True, exist_ok=True)

        scene_epsg = item.get("proj_epsg")
        total_bandas = len(bandas)
        files = []
        originals_to_delete = []
        convertidos = 0
        pulados = 0

        # ── Fase 1 — pré-varredura: pula produtos prontos e agenda downloads ──
        pendentes: dict = {}

        for idx, banda in enumerate(bandas, start=1):
            if progress_cb is not None:
                progress_cb(((idx - 1) / total_bandas) * 100.0)

            eh_scl = str(banda).upper() == "SCL"

            # Produto final esperado desta banda (`_refl.tif` quando convertido).
            final_produto = pasta_item / f"{prefixo}_{banda}.tif"
            if convert_uint16 and not eh_scl:
                final_produto = pasta_item / f"{prefixo}_{banda}_refl.tif"

            # Re-run seguro: se o produto final já existe na pasta, pula o
            # download/processamento e apenas reutiliza o arquivo (será
            # carregado no on_success). Evita WinError 183 / re-baixar tudo.
            if os.path.exists(str(final_produto)):
                try:
                    existe_valido = os.path.getsize(str(final_produto)) > 0
                except OSError:
                    existe_valido = True
                if existe_valido:
                    self.logger.info(
                        f"Produto já existe na pasta, pulando {banda}: "
                        f"{final_produto.name}",
                        code="IMAGERY_SKIP_EXISTING",
                        item=item.get("id"),
                        banda=banda,
                        path=str(final_produto),
                    )
                    files.append(str(final_produto))
                    pulados += 1
                    if progress_cb is not None:
                        progress_cb((idx / total_bandas) * 100.0)
                    continue

            asset_key = self.resolve_asset_key(item, cfg, banda)
            caminho_temp = pasta_item / f"_tmp_{banda}.tif"

            def _band_progress(part, base=idx - 1, total=total_bandas, cb=progress_cb):
                if cb is not None:
                    cb((base / total) * 100.0 + (part / total))

            pendentes[banda] = {
                "idx": idx,
                "ok": True,
                "asset_key": asset_key,
                "caminho_temp": caminho_temp,
                "progress": _band_progress,
            }

        # ── Fase 2 — downloads em paralelo (rede pura, FORA do lock GDAL) ──
        # A rede é o gargalo dominante; threads de I/O paralelas aumentam a
        # vazão agregada. O processamento pesado continua SERIALIZADO pelo
        # _GDAL_LOCK (regra SKILL_UTILS 2.3.2) — sem risco de crash.
        if pendentes:
            from concurrent.futures import ThreadPoolExecutor

            n_workers = max(1, min(MAX_BAND_DOWNLOADS, len(pendentes)))

            def _download_one(item_info: dict) -> None:
                """Baixa UMA banda (thread do pool), fora do lock GDAL."""
                self.download_asset(
                    item,
                    item_info["asset_key"],
                    item_info["caminho_temp"],
                    progress_cb=item_info["progress"],
                )

            with ThreadPoolExecutor(
                max_workers=n_workers, thread_name_prefix="imagery_dl"
            ) as _pool:
                _futures = {
                    banda: _pool.submit(_download_one, info)
                    for banda, info in pendentes.items()
                }

                # Re-lança erros de rede/HTTP por banda — 1 banda não derruba a cena.
                for banda, info in pendentes.items():
                    try:
                        _futures[banda].result()
                    except Exception as exc:  # noqa: BLE001
                        info["ok"] = False
                        self.logger.error(
                            f"Falha ao baixar banda {banda}, pulando: {exc}",
                            code="IMAGERY_BAND_DOWNLOAD_FAILED",
                            item=item.get("id"),
                            banda=banda,
                        )
                        if progress_cb is not None:
                            progress_cb((info["idx"] / total_bandas) * 100.0)

        # ── Fase 3 — processamento pesado de banda (clip, rename, ÷10000) ──
        # GDAL/numpy. Sempre SERIALIZADO via _GDAL_LOCK (regra SKILL_UTILS
        # 2.3.2): nunca rodar GDAL/numpy em 2 tasks paralelas do mesmo
        # processo (access violation → crash duro do QGIS sem exceção).
        for banda in bandas:
            info = pendentes.get(banda)
            if info is None or not info.get("ok", True):
                continue

            caminho_temp = info["caminho_temp"]

            with _GDAL_LOCK:
                # Fallback: se a cena não traz proj_epsg (certos casos STAC),
                # leemos o CRS real do raster recém baixado para poder recortar
                # pelo boundary e reprojetar corretamente.
                if not scene_epsg:
                    scene_epsg = self._get_raster_epsg(str(caminho_temp))
                    if scene_epsg:
                        self.logger.info(
                            f"proj_epsg recuperado do raster: EPSG:{scene_epsg}",
                            code="IMAGERY_EPSG_DERIVED",
                            item=item.get("id"),
                        )

                start_path = caminho_temp

                # 1. Clip por polígono (RasterVectorBridge, worker-safe paths)
                if clip_mode == "polygon" and clip_geom and clip_geom.get("polygon_path"):
                    out_clip = pasta_item / f"{prefixo}_{banda}_clip.tif"
                    if os.path.exists(str(out_clip)):
                        ExplorerUtils.delete_file(str(out_clip), tool_key=self.tool_key)
                    RasterVectorBridge().clip_raster_by_vector(
                        str(start_path),
                        str(clip_geom["polygon_path"]),
                        str(out_clip),
                        external_tool_key=self.tool_key,
                    )
                    start_path = out_clip
                # 2. Clip por boundary (sem polígono — bbox de raster/vetor/tela)
                elif clip_mode == "extent" and clip_geom and clip_geom.get("extent_wgs84"):
                    out_clip = pasta_item / f"{prefixo}_{banda}_clip.tif"
                    if os.path.exists(str(out_clip)):
                        ExplorerUtils.delete_file(str(out_clip), tool_key=self.tool_key)
                    start_path = self._clip_by_extent(
                        str(start_path),
                        clip_geom["extent_wgs84"],
                        scene_epsg,
                        str(out_clip),
                    )

                # 2.5 Reprojeção condicional (só se o EPSG de saída diferir do
                #     CRS da cena). Resolve "EPSG:xxxx" -> int e aplica gdal.Warp.
                epsg_out_int = self.resolve_epsg(epsg_out, scene_epsg)
                if epsg_out_int and scene_epsg and epsg_out_int != scene_epsg:
                    reproj_path = pasta_item / f"{prefixo}_{banda}_reproj.tif"
                    if os.path.exists(str(reproj_path)):
                        ExplorerUtils.delete_file(str(reproj_path), tool_key=self.tool_key)
                    start_path = self._reproject_raster(
                        str(start_path), epsg_out_int, str(reproj_path)
                    )

                # 3. Arquivo final base (sem conversão)
                final_path = pasta_item / f"{prefixo}_{banda}.tif"
                if start_path != final_path:
                    if os.path.exists(str(final_path)):
                        ExplorerUtils.delete_file(str(final_path), tool_key=self.tool_key)
                    try:
                        os.replace(str(start_path), str(final_path))
                    except OSError as e:
                        self.logger.warning(
                            f"Falha ao mover '{start_path}': {e}",
                            code="IMAGERY_MOVE_RENAME",
                        )
                        ExplorerUtils.rename_file(
                            str(start_path), str(final_path), tool_key=self.tool_key
                        )

                # 4. Conversão uint16 → float32 (÷10000); SCL passa direto
                if convert_uint16:
                    refl_path = pasta_item / f"{prefixo}_{banda}_refl.tif"
                    RasterLayerProcessing.scale_raster_to_float32(
                        str(final_path),
                        str(refl_path),
                        band_name=banda,
                        tool_key=self.tool_key,
                    )
                    if os.path.exists(str(refl_path)):
                        files.append(str(refl_path))
                        convertidos += 1
                        if delete_originals and os.path.exists(str(final_path)):
                            originals_to_delete.append(str(final_path))
                        continue

                files.append(str(final_path))

        # ── Composições selecionadas (ex.: RGB → B04+B03+B02) ─────────
        # Gera o raster multibanda composto a partir das bandas já baixadas.
        # Resolução mista (20m+10m) é unificada re-amostrando as bandas grossas
        # para a resolução da banda mais fina da composição (evita empilhamento
        # inválido de grids diferentes no BuildVRT).
        composicoes_geradas = 0
        composite_files = []
        for comp_key in (compositions or []):
            comp = cfg["compositions"].get(comp_key)
            if not comp:
                self.logger.warning(
                    f"Composição desconhecida {comp_key} — ignorada",
                    code="IMAGERY_COMP_UNKNOWN",
                    comp=comp_key,
                )
                continue

            bandas_comp = comp.get("bandas") or []
            if len(bandas_comp) < 3:
                self.logger.info(
                    f"Composição {comp_key} exige <3 bandas — pulando",
                    code="IMAGERY_COMP_MIN_BANDS",
                    comp=comp_key,
                    bandas=bandas_comp,
                )
                continue

            # Resolução objetivo = a mais fina entre as bandas da composição.
            ress = {
                cfg["assets"].get(b, ("", ""))[1]
                for b in bandas_comp if b in cfg["assets"]
            }
            target_res = None
            for r_str in ress:
                r = self._band_resolucion_m(r_str)
                if r is not None and (target_res is None or r < target_res):
                    target_res = r

            band_files = []
            faltando = False
            for b in bandas_comp:
                p = self._composicao_banda_path(
                    pasta_item, prefixo, b, convert_uint16
                )
                if not os.path.exists(str(p)) or os.path.getsize(str(p)) <= 0:
                    faltando = True
                    break

                b_res = self._band_resolucion_m(
                    cfg["assets"].get(b, ("", ""))[1]
                )
                # Banda mais grossa que o alvo -> reamostrar antes de empilhar
                if target_res and b_res and b_res > target_res:
                    resampled = pasta_item / (
                        f"{prefixo}_{b}_{comp_key}_res{int(target_res)}m.tif"
                    )
                    if (
                        not os.path.exists(str(resampled))
                        or os.path.getsize(str(resampled)) <= 0
                    ):
                        with _GDAL_LOCK:
                            try:
                                self._resample_raster(
                                    str(p), str(resampled), target_res
                                )
                            except Exception as e:  # noqa: BLE001
                                self.logger.warning(
                                    f"Falha ao reamostrar {b} para {comp_key}: {e}",
                                    code="IMAGERY_COMP_RESAMPLE_FAILED",
                                    comp=comp_key,
                                    banda=b,
                                )
                                faltando = True
                                break
                    band_files.append(str(resampled))
                else:
                    band_files.append(str(p))

            if faltando:
                self.logger.warning(
                    f"Uma ou mais bandas da composição {comp_key} não baixadas — pulando",
                    code="IMAGERY_COMP_MISSING_BAND",
                    comp=comp_key,
                    bandas_comp=bandas_comp,
                )
                continue

            comp_path = pasta_item / f"{prefixo}_{comp_key}.tif"
            with _GDAL_LOCK:
                try:
                    RasterLayerProcessing.compose_multiband_raster(
                        band_files,
                        str(comp_path),
                        tool_key=self.tool_key,
                    )
                except Exception as e:  # noqa: BLE001 - 1 comp. não derruba a cena
                    self.logger.error(
                        f"Falha ao compor {comp_key}: {e}",
                        code="IMAGERY_COMP_FAILED",
                        comp=comp_key,
                    )
                    continue
            files.append(str(comp_path))
            composite_files.append(str(comp_path))
            composicoes_geradas += 1
            self.logger.info(
                f"Composição {comp_key} gerada: {comp_path.name}",
                code="IMAGERY_COMP_DONE",
                comp=comp_key,
                path=str(comp_path),
            )

        if progress_cb is not None:
            progress_cb(100.0)

        # Metadados da cena (RF13)
        meta = {
            "id": item.get("id"),
            "data": item.get("datetime"),
            "tile": item.get("tile"),
            "plataforma": item.get("plataforma"),
            "nuvens_%": item.get("nuvens"),
            "epsg_original": scene_epsg,
            "epsg_saida": epsg_out,
            "clip_mode": clip_mode,
            "bandas_baixadas": [Path(f).name for f in files],
            "convertidos_/10000": convertidos,
            "pulados_existentes": pulados,
            "composicoes_geradas": composicoes_geradas,
            "apagar_originais": delete_originals,
        }
        meta_path = pasta_item / f"{prefixo}_metadata.json"
        with open(str(meta_path), "w", encoding="utf-8") as fh:
            json.dump(meta, fh, ensure_ascii=False, indent=2, default=str)

        self.logger.info(
            f"process_item: {len(files)} arquivos ({pulados} já existentes pulados) "
            f"({pasta_item})",
            code="IMAGERY_ITEM_DONE",
            item=item.get("id"),
            bandas=len(bandas),
            pulados=pulados,
        )
        return {
            "item_id": item.get("id"),
            "prefix": prefixo,
            "folder": str(pasta_item),
            "files": files,
            "composite_files": composite_files,
            "originals_to_delete": originals_to_delete,
            "metadata": str(meta_path),
        }
